clc;
clear;
global t r

% Time vector and step input
t = 0:0.01:50;
r = ones(size(t));

% Transfer functions
G_Z = tf(1, [1 3 1]);
G_Y = tf(1, [1 2.5 1]);
G_X = tf(1, [1 2 1]);

% ACO Parameters
num_ants = 15;
max_iter = 50;
lb = [0 0 0];
ub = [3 1 2];

% Objective function (returns scalar ITAE)
ITAE = @(K, G) sum(t .* abs(r(:) - lsim(series(pid(K(1), K(2), K(3)), G), r(:), t(:))));
fitnessZ = @(K) ITAE(K, G_Z);
fitnessY = @(K) ITAE(K, G_Y);
fitnessX = @(K) ITAE(K, G_X);

% Run ACO
[bestZ, ~] = aco_pid(fitnessZ, lb, ub, num_ants, max_iter);
[bestY, ~] = aco_pid(fitnessY, lb, ub, num_ants, max_iter);
[bestX, ~] = aco_pid(fitnessX, lb, ub, num_ants, max_iter);

% Display results
fprintf('\nBest ACO PID Gains:\n');
fprintf('Z-axis: Kp = %.4f, Ki = %.4f, Kd = %.4f\n', bestZ(1), bestZ(2), bestZ(3));
fprintf('Y-axis: Kp = %.4f, Ki = %.4f, Kd = %.4f\n', bestY(1), bestY(2), bestY(3));
fprintf('X-axis: Kp = %.4f, Ki = %.4f, Kd = %.4f\n', bestX(1), bestX(2), bestX(3));

% Plot
figure;
lsim(series(pid(bestZ(1), bestZ(2), bestZ(3)), G_Z), r, t);
title('ACO-PID: Z Axis'); xlabel('Time (s)'); ylabel('Amplitude');

figure;
lsim(series(pid(bestY(1), bestY(2), bestY(3)), G_Y), r, t);
title('ACO-PID: Y Axis'); xlabel('Time (s)'); ylabel('Amplitude');

figure;
lsim(series(pid(bestX(1), bestX(2), bestX(3)), G_X), r, t);
title('ACO-PID: X Axis'); xlabel('Time (s)'); ylabel('Amplitude');                                                                                                          