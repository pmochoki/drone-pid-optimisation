clc;
clear;

% Time and step input
t = 0:0.05:10;
r = ones(size(t)) * 5;
Gz = tf(1, [0.5 1 0]);

% === PSO-Tuned PID Gains (Z-Axis) ===
Kp = 0;
Ki = 0;
Kd = 1;

% Simulate response
C = pid(Kp, Ki, Kd);
sys = feedback(C * Gz, 1);
z = lsim(sys, r, t);

% Sphere drone geometry
[XS, YS, ZS] = sphere(25);
radius = 0.2;
XS = radius * XS;
YS = radius * YS;

% Frame capture indices
idx_0 = 1;
idx_5 = round(length(t)/2);
idx_10 = length(t);

altitudes = [z(idx_0), z(idx_5), z(idx_10)];
labels = {'Start (0s)', 'Mid-Air (5s)', 'Hover (10s)'};

for k = 1:3
    Z = ZS + altitudes(k);
    
    figure('Color','w');
    grid on;
    xlabel('X'); ylabel('Y'); zlabel('Z (Altitude)');
    xlim([-0.5 0.5]); ylim([-0.5 0.5]); zlim([0 6]);
    view(45, 25);
    title(['Drone Z-Axis - ', labels{k}, ' [PSO PID]']);
    
    surf(XS, YS, Z, 'FaceColor', 'm', 'EdgeColor', 'none');
end