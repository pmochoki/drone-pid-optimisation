clc;
clear;

% Time and step input
t = 0:0.05:10;
r = ones(size(t)) * 5;                  % Altitude step to 5 meters
Gz = tf(1, [0.5 1 0]);                  % Z-axis transfer function

% === GWO-Tuned PID Gains (Z-Axis) ===
Kp = 6.6877;
Ki = 0.0884;
Kd = 0.3859;

% Simulate altitude response
C = pid(Kp, Ki, Kd);
sys = feedback(C * Gz, 1);
z = lsim(sys, r, t);

% Sphere drone geometry
[XS, YS, ZS] = sphere(25);
radius = 0.2;
XS = radius * XS;
YS = radius * YS;

% Frame selection
idx_0 = 1;
idx_5 = round(length(t)/2);
idx_10 = length(t);

altitudes = [z(idx_0), z(idx_5), z(idx_10)];
labels = {'Start (0s)', 'Mid-Air (5s)', 'Hover (10s)'};

for k = 1:3
    Z = ZS + altitudes(k);  % Raise the sphere
    
    figure('Color','w');
    grid on;
    xlabel('X'); ylabel('Y'); zlabel('Z (Altitude)');
    xlim([-0.5 0.5]); ylim([-0.5 0.5]); zlim([0 6]);
    view(45, 25);
    title(['Drone Z-Axis - ', labels{k}, ' [GWO PID]']);
    
    surf(XS, YS, Z, 'FaceColor', 'b', 'EdgeColor', 'none');  % GWO = Blue
end