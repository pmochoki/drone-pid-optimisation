clc; clear;
t = 0:0.05:10;
r = ones(size(t)) * 5;
Gy = tf(1, [0.3 1 0]);

% PID Tuner Gains
Kp = 3.912;
Ki = 1.509;
Kd = 1.022;

C = pid(Kp, Ki, Kd);
sys = feedback(C * Gy, 1);
y = lsim(sys, r, t);

[XS, YS, ZS] = sphere(25);
radius = 0.15;
XS = radius * XS;
YS = radius * YS;

idx = [1, round(length(t)/2), length(t)];
pos = [y(idx(1)), y(idx(2)), y(idx(3))];
labels = {'Start (0s)', 'Mid-Roll (5s)', 'Stable (10s)'};

for k = 1:3
    figure('Color','w');
    grid on;
    xlabel('X'); ylabel('Y (Roll)'); zlabel('Z');
    xlim([0 6]); ylim([-0.5 0.5]); zlim([-0.5 0.5]);
    view(45, 25);
    title(['Drone Y-Axis - ', labels{k}, ' [PID Tuner]']);
    surf(XS + pos(k), YS, ZS, 'FaceColor', [0.2 0.6 1], 'EdgeColor', 'none');
end